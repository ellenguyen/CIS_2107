// Fig. 2.4: fig02_04.c
// Printing multiple lines with a single printf
#include <stdio.h>

// function main begins program execution
int main(void)
{
   printf("Welcome\nto\nC!\n");
} // end function main
