// Fig. 2.3: fig02_03.c
// Printing on one line with two printf statements 
#include <stdio.h>

// function main begins program execution 
int main( void )
{
   printf( "Welcome " );
   printf( "to C!\n" ); 
} // end function main 

